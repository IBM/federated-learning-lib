"""
Licensed Materials - Property of IBM
Restricted Materials of IBM
20190891
© Copyright IBM Corp. 2020 All Rights Reserved.
"""
import logging

import numpy as np

from ibmfl.exceptions import LocalTrainingException, \
    ModelUpdateException
from ibmfl.model.model_update import ModelUpdate
from ibmfl.party.training.local_training_handler import \
    LocalTrainingHandler

logger = logging.getLogger(__name__)


class FedPlusLocalTrainingHandler(LocalTrainingHandler):

    def __init__(self, fl_model, data_handler, info=None, **kwargs):
        """
        Initialize LocalTrainingHandler with fl_model, data_handler

        :param fl_model: model to be trained
        :type fl_model: `model.FLModel`
        :param data_handler: data handler that will be used to obtain data
        :type data_handler: `DataHandler`
        :param info: Hyperparameters used for training.
        :type info: `dict`
        :param kwargs: Additional arguments to initialize a local training \
        handler, e.g., a crypto library object to help with encryption and \
        decryption.
        :type kwargs: `dict`
        :return None
        """
        super().__init__(fl_model, data_handler, hyperparams=info, **kwargs)
        self.fl_model = fl_model
        self.data_handler = data_handler
        self.info = info
        self.alpha = 0
        if info is not None:
            self.alpha = info.setdefault("alpha", 0)
        if self.alpha < 0 or self.alpha > 1:
            raise ValueError('alpha should be between 0 and 1')

    def update_model(self, model_update):
        """
        Update local model with model updates received from FusionHandler

        :param model_update: ModelUpdate
        :type model_update: `ModelUpdate`
        """
        try:
            if model_update is not None:
                self.soft_update_model(model_update)
                logger.info('Local model updated.')
            else:
                logger.info('No model update was provided.')
        except Exception as ex:
            raise LocalTrainingException('No query information is provided',
                                         str(ex))

    def sync_model(self, payload=None):
        """
        Update the local model with global ModelUpdate received \
        from the Aggregator.

        :param payload: data payload received from Aggregator
        :type payload: `dict`
        :return: Status of sync model request
        :rtype: `boolean`
        """
        status = False
        if payload is None or 'model_update' not in payload:
            raise ModelUpdateException(
                "Invalid Model update request aggregator")
        try:
            model_update = payload['model_update']
            self.soft_update_model(model_update)
        except Exception as ex:
            logger.error("Exception occurred while sync model")
            logger.exception(ex)

        return status

    def soft_update_model(self, model_update, key='weights'):
        """
        Soft update to local model using global model and tuning alpha value

        :param model_update:ModelUpdate
        :type model_update: `ModelUpdate`
        :param key: model weights
        :type key:str
        :return:None
        """
        local_weights = self.fl_model.get_model_update().get(key)
        global_weights = model_update.get(key)
        soft_update_weights = np.add((1 - self.alpha) * np.array(local_weights), self.alpha * np.array(global_weights))
        self.fl_model.update_model(model_update=ModelUpdate(weights=soft_update_weights))
