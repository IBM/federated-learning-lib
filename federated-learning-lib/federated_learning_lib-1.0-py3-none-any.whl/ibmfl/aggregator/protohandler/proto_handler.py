"""
Licensed Materials - Property of IBM
Restricted Materials of IBM
20190891
© Copyright IBM Corp. 2020 All Rights Reserved.
"""
"""
Module which will control overall Federated
Learning algorithm such as plain FL, homomorphic encryption,
Hybrid-one etc.
"""
import logging
import abc
import time
import uuid
from multiprocessing.pool import ThreadPool
from ibmfl.aggregator.party_connection import PartyConnection
from ibmfl.aggregator.states import States
from ibmfl.message.message import Message
from ibmfl.message.message_type import MessageType
from ibmfl.exceptions import GlobalTrainingException, FLException
logger = logging.getLogger(__name__)


class ProtoHandler(abc.ABC):
    """
    Base class for ProtoHandler (global federated learning algorithm)
    """

    def __init__(self, connection, synch=False, max_timeout=None):
        """
        Initializes an `ProtoHandler` object

        :param connection: connection that will be used to send messages
        :type connection: `Connection`
        :param synch: get model update synchronously
        :type synch: `boolean`
        :param max_timeout: time in seconds to wait for parties
        :type max_timeout: `int`
        """
        # List of parties involved in Federated Learning
        self.parties_list = dict()
        self.dropped_parties_list = []
        self.connection = connection
        self.synch = synch
        self.state = States.START
        self.max_timeout = max_timeout
        logger.info("State: " + str(self.state))

    def add_party(self, party):
        """
        Add a data party to federated learning process

        :param party: party details that are needed by the protocol handler
        :type party: `PartyConnection`
        :return id: guid assigned to the party
        :type id: `uuid`
        """
        if isinstance(party.info, str):
            id = party.info
        elif 'id' in party.info.keys() and party.info['id'] is not None:
            id = str(party.info['id'])
        else:
            id = str(uuid.uuid4())
        self.parties_list[id] = party
        logger.info("Adding party with id " + id)
        return id

    def send_different_message_concurrently(self, party_ids,
                                            messages):
        """
        Send a message to list of parties asynchronously

        :param party_ids: list of parties to query
        :type party_ids: `list`
        :param messages: List of Messages to be sent to party
        :type messages: `list`
        :return: Response message status
        :rtype: `boolean`
        """
        results = []
        self.state = States.SND_REQ
        logger.info("State: " + str(self.state))

        if len(party_ids) == 0:
            logger.info('No data party registered!')
            return
        if len(party_ids) != len(messages):
            logger.error('number of parties and messages are not equal.')
            return
        pool = ThreadPool(processes=len(party_ids))
        for id, message in zip(party_ids, messages):
            # Query each party
            results.append(pool.apply_async(
                self.send_message, (id, message)))
        pool.close()
        pool.join()
        results = [r.get() for r in results]
        logger.info('Total number of success responses :{}'.format(
            sum(results)))

    def send_message(self, party_id, message):
        """
        Send a message to party

        :param party: party to query
        :type party: `PartyConnection`
        :param message: Message to be sent to party
        :type message: `Message`
        :return: Response message status
        :rtype: `boolean`
        """
        try:
            res_status = False
            party = self.get_party_by_id(party_id)
            res_msg = self.connection.send_message(party.info, message)

            if res_msg:
                data = res_msg.get_data()

                if 'status' in data and data['status'] == 'error':
                    logger.error('Error occured in party.')
                if self.synch:
                    party.add_new_reply(res_msg.get_header()[
                                        'id_request'], data)
                    res_status = True
                else:
                    # This check is here for test cases that uses connection stub
                    if 'ACK' not in data and 'model_update' in data:
                        party.add_new_reply(res_msg.get_header()['id_request'],
                                            data)
                    else:
                        party.add_new_reply(message.get_header()['id_request'],
                                            data)
                    res_status = True
            else:
                logger.error('Invalid response from party.')
        except Exception as fl_ex:
            # Populate dropped party list to make sure we exclude this party
            self.dropped_parties_list.append(party)
            logger.exception("Error occurred while sending request to party: "
                             + str(party) + " - " + str(fl_ex))
            return False

        return res_status

    def query_parties(self, party_ids, data, msg_type=MessageType.TRAIN):
        """
        Query a list of parties by constructing a message with MessageType
        default as `TRAIN` and packaging the data as payload.

        :param party_ids: List of parties selected for an epoch
        :type party_ids: `lst`
        :param data: query information which is sent to each party
        :type data: `dict`
        :param msg_type: The type of message the query should belong in. \
        The default type is TRAIN, which allows the router to direct \
        this type of queries to the `train` method defined \
        inside the `LocalTrainingHandler` class. \
        See `MessageType` class for other possible messages types.
        :type: `MessageType`
        :return: message number
        :rtype: `int`
        """
        if not isinstance(msg_type, MessageType):
            raise FLException(
                "Provided message type should be of type MessageType. "
                "Instead it is of type " + str(type(msg_type)))

        try:
            message = Message(msg_type.value, data={'payload': data})
        except Exception as ex:
            logger.exception(ex)
            raise FLException("Error occurred when constructing message.")

        id_request = message.get_header()['id_request']

        try:
            messages = [message for _ in range(len(party_ids))]
            self.send_different_message_concurrently(party_ids, messages)
        except Exception as fl_ex:
            logger.exception('Error occurred while sending {} request '
                             'to parties'.format(str(msg_type)) + str(fl_ex))
            raise FLException('Error occurred while sending {} request '
                              'to parties'.format(str(msg_type)))
        return id_request

    def query_parties_data(self, party_ids, data_queries,
                           msg_type=MessageType.TRAIN):
        """
        Query a list of parties by constructing a message with MessageType
        as `TRAIN` and packaging the data as payload

        :param party_ids: List of parties selected for an epoch
        :type party_ids: `lst`
        :param data_queries: query information which is sent to each party
        :type data_queries: `lst`
        :param msg_type: The type of message the query should belong in. \
        The default type is TRAIN, which allows the router to direct \
        this type of queries to the `train` method defined \
        inside the `LocalTrainingHandler` class. \
        See `MessageType` class for other possible messages types.
        :type: `MessageType`
        :return: list of message numbers
        :rtype: `list`
        """
        messages = []
        id_request_lst = []

        if len(party_ids) != len(data_queries):
            logger.error('Number of parties and messages are not equal.')
            raise GlobalTrainingException(
                'Number of parties and messages are not equal.')
        for data in data_queries:
            try:
                message = Message(msg_type.value, data={'payload': data})
            except Exception as ex:
                logger.exception(ex)
                raise FLException(
                    "Error occurred when constructing message.")
            id_request = message.get_header()['id_request']
            messages.append(message)
            id_request_lst.append(id_request)

        try:
            self.send_different_message_concurrently(party_ids, messages)
        except Exception as fl_ex:
            logger.exception('Error occurred while sending {} request '
                             'to parties'.format(str(msg_type)) + str(fl_ex))
            raise FLException('Error occurred while sending {} request '
                              'to parties'.format(str(msg_type)))
        return id_request_lst

    def sync_model_parties(self, party_ids, data):
        """
        Send global model to a list of parties by constructinga message
        with MessageType as `SYNC` and packaging the model as payload

        :param party_ids: List of parties selected for an epoch
        :type party_ids: `lst`
        :param data: query information which is sent to each party
        :type data: `dict`
        :return: message number
        :rtype: `int`
        """
        message = Message(MessageType.SYNC_MODEL.value, data={'payload': data})
        id_request = message.get_header()['id_request']

        try:
            messages = [message for _ in range(len(party_ids))]

            self.send_different_message_concurrently(party_ids, messages)
        except Exception as fl_ex:
            logger.exception(
                'Error occurred while sending SYNC_MODEL request to parties'
                + str(fl_ex))
            raise FLException(
                'Error occurred while sending SYNC_MODEL request to parties')
        return id_request

    def save_model_parties(self, party_ids, data):
        """
        Send save model request to parties by constructing a message with
        MessageType as `SAVE_MODEL` and packaging the data as payload

        :param party_ids: List of parties selected for an epoch
        :type party_ids: `lst`
        :param data: query information which is sent to each party
        :type data: `dict`
        :return: message number
        :rtype: `int`
        """
        message = Message(MessageType.SAVE_MODEL.value, data={'payload': data})
        id_request = message.get_header()['id_request']

        try:
            messages = [message for _ in range(len(party_ids))]

            self.send_different_message_concurrently(party_ids, messages)
        except Exception as fl_ex:
            logger.exception(
                'Error occurred while sending SAVE request to parties'
                + str(fl_ex))
            raise FLException(
                'Error occurred while sending SAVE request to parties')
        return id_request

    def eval_model_parties(self, party_ids, data):
        """
        Send eval request to parties by constructing a message with
        MessageType as `EVAL_MODEL` and packaging the data as payload

        :param party_ids: List of parties selected for an epoch
        :type party_ids: `list`
        :param data: query information which is sent to each party
        :type data: `dict`
        :return: message number
        :rtype: `int`
        """
        message = Message(MessageType.EVAL_MODEL.value,
                          data={'payload': data})
        id_request = message.get_header()['id_request']

        try:
            messages = [message for _ in range(len(party_ids))]

            self.send_different_message_concurrently(party_ids, messages)
        except FLException as fl_ex:
            logger.exception(
                'Error occurred while sending request to parties' + str(fl_ex))
            # raise Exception
        return id_request

    def stop_parties(self):
        """
        STOP all available parties.

        :return: message number
        :rtype: `int`
        """
        party_ids = self.get_available_parties()

        message = Message(MessageType.STOP.value, None)
        id_request = message.get_header()['id_request']

        try:
            messages = [message for _ in range(len(party_ids))]

            self.send_different_message_concurrently(party_ids, messages)
        except Exception as fl_ex:
            logger.exception(
                'Error occurred while sending STOP request to parties'
                + str(fl_ex))
        return id_request

    def get_available_parties(self):
        """
        Returns all registered parties.

        :return: List of registered parties
        :rtype: `list` of `PartyConnection`
        """
        lst_parties = list(self.parties_list.keys())
        if not lst_parties or len(lst_parties) == 0:
            raise GlobalTrainingException(
                'Insufficient number of parties to start training.')

        for party in lst_parties:
            if self.get_party_by_id(party) in self.dropped_parties_list:
                lst_parties.remove(party)

        return lst_parties

    def get_party_by_id(self, id):
        """
        Get `Party_Connection` object using id
        :param id: dictionary with information about source
        :type id: `uuid`

        :return: party
        :rtype: `PartyConnection`
        """
        if id in self.parties_list:
            return self.parties_list[id]
        else:
            logger.error('Unknown party id '+str(id))
            raise GlobalTrainingException(
                'Unknown party id')

    def get_party_by_info(self, info):
        """
        Get `Party_Connection` object using info received in message
        :param info: Dictionary with information about source
        :type info: `dict`

        :return: party
        :rtype: `PartyConnection`
        """
        for party in self.parties_list.values():
            if info == party.info:
                return party

    def get_n_parties(self):
        """
        Return the number of parties as specified in the aggregator config
        file, which determines the legnth of parties_list

        :return: Number of parties that the aggregator expects to connect to
        :rtype: `int`
        """
        return len(self.parties_list)

    def register_party(self, message):
        """
        Register data party
        :param message: Request received by the server
        :type message: `Message`

        :return: Message with success response
        :rtype: `Message`
        """
        message_info = message.get_sender_info()
        new_party = PartyConnection(message_info)
        # TODO: check for duplicates and raise exception/send error response
        # TODO: handle invalid requests
        id = self.add_party(new_party)
        data = {'status': 'success', 'id': id}
        message.set_data(data)
        return message

    def process_model_update_requests(self, message):
        """
        Save model update request send from party

        :param message: request send by party
        :type message: `Message`

        :return: Message with appropriate response
        :rtype: `Message`
        """

        data = message.get_data()
        header = message.get_header()
        info = header['sender_info']
        id_request = header['id_request']

        party = self.get_party_by_info(info)
        party.add_new_reply(id_request, data)

        data = {'status': 'success'}
        message.set_data(data)
        return message

    def quorum_failed_party(self, party_ids,
                            id_request=None,
                            id_request_list=None):
        """
        Verifies the parties that failed during quorum

        :param party_ids: List of parties that have received query
        :type party_ids: `list`
        :param id_request: Current id_request
        :type id_request: `int`
        :param id_request_list: A list of id number link to the query that \
        needs quorum verification
        :type id_request_list: `list`
        :return: None
        """
        if id_request is None and id_request_list is None:
            logger.error('No request id provided.')
            raise GlobalTrainingException(
                'No request id provided.')
        elif id_request and id_request_list:
            raise GlobalTrainingException(
                'Both id_request and id_request_list cannot be provided at once.')
        if id_request:
            for p in party_ids:
                if not self.get_party_by_id(p).has_party_replied(id_request):
                    if p not in self.dropped_parties_list:
                        self.dropped_parties_list.append(p)
        else:
            for p, p_id in zip(party_ids, id_request_list):
                if not self.get_party_by_id(p).has_party_replied(p_id):
                    if p not in self.dropped_parties_list:
                        self.dropped_parties_list.append(p)

    def has_reached_quorum(self, party_ids, id_request=None,
                           id_request_list=None, perc_quorum=1.):
        """
        Verifies if quorum has been reached. If it has, it returns True,
        otherwise it returns False.

        :param party_ids: List of parties that have received query
        :type party_ids: `list`
        :param id_request: current id_request
        :type id_request: `int`
        :param id_request_list: A list of id number link to the query that \
        needs quorum verification
        :type id_request_list: `list`
        :param perc_quorum: A float to specify percentage of parties that \
        are needed for quorum to reach
        :type perc_quorum: `float`

        :return: Quorum status
        :rtype: `boolean`
        """
        if id_request is None and id_request_list is None:
            logger.error('No request id provided.')
            raise GlobalTrainingException(
                'No request id provided.')
        elif id_request and id_request_list:
            raise GlobalTrainingException(
                'Both id_request and id_request_list cannot be provided '
                'at once. ')

        if id_request:
            quorum = 0
            target_quorum = int(len(party_ids) * perc_quorum)
            logger.info("Target Qorum: " + str(target_quorum))
            for p in party_ids:
                if self.get_party_by_id(p).has_party_replied(id_request):
                    quorum += 1
            if quorum >= target_quorum:
                return True
            return False
        else:
            quorum = 0
            target_quorum = int(len(party_ids) * perc_quorum)
            logger.info("Target Qorum: " + str(target_quorum))
            for p, p_id in zip(party_ids, id_request_list):
                if self.get_party_by_id(p).has_party_replied(p_id):
                    quorum += 1
            if quorum >= target_quorum:
                return True
            return False

    def periodically_verify_quorum(self, party_ids, id_request=None,
                                   id_request_list=None, perc_quorum=1.):
        """
        Periodically verifies if enough replies from parties in party_ids
        for the current query identified by `id_request` have been received.
        If it has, returns True, and if it doesn't in a maximum pre-defined
        time, it throws an exception

        :param party_ids: List of parties selected for an epoch
        :type party_ids: `list`
        :param id_request: An id number link to the query that \
        needs quorum verification
        :param id_request_list: A list of id number link to the query that \
        needs quorum verification
        :type id_request_list: `list`
        :param perc_quorum: A float to specify percentage of parties that \
        are needed for quorum to reach
        :type perc_quorum: `float`
        :return: boolean indicating if quorum has been reached
        :rtype: `boolean`
        """
        self.state = States.QUORUM_WAIT
        logger.info("State: " + str(self.state))
        if id_request is None and id_request_list is None:
            logger.error('No request id provided.')
            raise GlobalTrainingException(
                'No request id provided.')
        if id_request is not None and id_request_list is None:
            start = time.time()
            while not self.has_reached_quorum(party_ids, id_request,
                                              perc_quorum=perc_quorum):
                # For now it we simply sleep for a while
                time.sleep(5)
                logger.info("Timeout:" + str(self.max_timeout)
                            + " Time spent:"
                            + str(round(time.time()-start)))
                if self.max_timeout:
                    # Update dropped out parties list
                    if (round(time.time()-start) >= self.max_timeout):
                        logger.error('Party did not reply in time.')
                        self.quorum_failed_party(party_ids, id_request)
                        raise GlobalTrainingException(
                            'Max-timeout: quorum not reached. Party did not reply in time.')
            self.state = States.PROC_RSP
            logger.info("State: " + str(self.state))
            return True
        elif id_request_list is not None and id_request is None:
            while not self.has_reached_quorum(party_ids,
                                              id_request_list=id_request_list,
                                              perc_quorum=perc_quorum):
                time.sleep(5)
            self.state = States.PROC_RSP
            logger.info("State: " + str(self.state))
            return True


class ProtoHandlerRabbitMQ(ProtoHandler):
    """
    Extended class for ProtoHandler (global federated learning algorithm),
    for using with RabbitMQ connection
    """

    def __init__(self, connection, synch=True, max_timeout=None):
        """
        Initializes an `ProtoHandlerRabbitMQ` object

        :param connection: Connection that will be used to send messages
        :type connection: `Connection`
        :param synch: Get model update synchronously
        :type synch: `boolean`
        """
        if synch:
            super(ProtoHandlerRabbitMQ, self).__init__(
                connection,
                synch,
                max_timeout
            )

        else:
            raise FLException(
                'RabbitMQ connection currently only supports synchronous mode'
            )

    def send_message(self, message):
        """
        Send a message to all parties

        :param message: Message to be sent to parties
        :type message: `Message`
        """
        self.connection.send_message('', message)

    def send_messages(self, party_ids, messages):
        """
        Send multiple messages to multiple parties

        :param party_ids: List of parties selected for an epoch
        :type party_ids: `list`
        :param messages: Message to be sent to parties
        :type messages: `Message`
        """
        self.connection.send_messages(party_ids, messages)

    def receive_messages(self, party_ids):
        """
        Receive model updates from parties

        :param party_ids: List of parties selected for an epoch
        :type party_ids: `list`
        """
        results = {}
        id_requests = {}
        for _ in range(len(party_ids)):
            res = self.connection.receiver.receive_message()
            results[res[0]] = res[1].get_data()
            id_requests[res[0]] = res[1].get_header()['id_request']

        for id in party_ids:
            party = self.get_party_by_id(id)
            party.add_new_reply(id_requests[party.info], results[party.info])

    def query_parties(self, party_ids, data, msg_type=MessageType.TRAIN):
        """
        Query a list of parties by constructing a message with MessageType
        as `TRAIN` and packaging the data as payload

        :param party_ids: List of parties selected for an epoch
        :type party_ids: `list`
        :param data: query information which is sent to each party
        :type data: `dict`
        :param msg_type: The type of message the query should belong in. \
        The default type is TRAIN, which allows the router to direct \
        this type of queries to the `train` method defined \
        inside the `LocalTrainingHandler` class. \
        See `MessageType` class for other possible messages types.
        :type msg_type: `MessageType`
        :return: message number
        :rtype: `int``
        """
        self.connection.receiver.set_stopable()
        self.connection.receiver_thread.join()

        if not isinstance(msg_type, MessageType):
            raise FLException(
                "Provided message type should be of type MessageType. "
                "Instead it is of type " + str(type(msg_type))
            )

        try:
            message = Message(msg_type.value, data={'payload': data})
        except Exception as ex:
            logger.exception(ex)
            raise FLException("Error occurred when constructing message.")

        id_request = message.get_header()['id_request']

        try:
            self.send_message(message)

        except Exception as fl_ex:
            logger.exception(
                'Error occurred while sending TRAIN request to parties'
                + str(fl_ex)
            )
            raise FLException(
                'Error occurred while sending TRAIN request to parties'
            )

        try:
            self.receive_messages(party_ids)

        except Exception as fl_ex:
            logger.exception(
                'Error occurred while receiving local TRAIN results from'
                ' parties' + str(fl_ex)
            )
            raise FLException(
                'Error occurred while receiving local TRAIN results from'
                ' parties'
            )

        return id_request

    def query_parties_data(self, party_ids, data_queries,
                           msg_type=MessageType.TRAIN):
        """
        Query a list of parties by constructing a message with MessageType
        as `TRAIN` and packaging the data as payload

        :param party_ids: List of parties selected for an epoch
        :type party_ids: `list`
        :param data_queries: Query information which is sent to each party
        :type data_queries: `list`
        :param msg_type: The type of message the query should belong in. \
        The default type is TRAIN, which allows the router to direct \
        this type of queries to the `train` method defined \
        inside the `LocalTrainingHandler` class. \
        See `MessageType` class for other possible messages types.
        :type msg_type: `MessageType`
        :return: list of message numbers
        :rtype: `list`
        """
        self.connection.receiver.set_stopable()
        self.connection.receiver_thread.join()

        messages = []
        id_request_lst = []

        if len(party_ids) != len(data_queries):
            logger.error('Number of parties and messages are not equal.')
            raise GlobalTrainingException(
                'Number of parties and messages are not equal.'
            )

        for data in data_queries:
            try:
                message = Message(msg_type.value, data={'payload': data})
            except Exception as ex:
                logger.exception(ex)
                raise FLException(
                    "Error occurred when constructing message."
                )

            id_request = message.get_header()['id_request']

            messages.append(message)
            id_request_lst.append(id_request)

        try:
            self.send_messages(party_ids, messages)

        except Exception as fl_ex:
            logger.exception(
                'Error occurred while sending TRAIN request to parties'
                + str(fl_ex)
            )
            raise FLException(
                'Error occurred while sending TRAIN request to parties'
            )

        try:
            self.receive_messages(party_ids)

        except Exception as fl_ex:
            logger.exception(
                'Error occurred while receiving local TRAIN results from'
                ' parties' + str(fl_ex)
            )
            raise FLException(
                'Error occurred while receiving local TRAIN results from'
                ' parties'
            )

        return id_request_lst

    def eval_model_parties(self, party_ids, data):
        """
        Send eval request to parties by constructing a message with
        MessageType as `EVAL_MODEL` and packaging the data as payload

        :param party_ids: List of parties selected for an epoch
        :type party_ids: `list`
        :param data: query information which is sent to each party
        :type data: `dict`
        :return: message number
        :rtype: `int`
        """
        self.connection.receiver.set_stopable()
        self.connection.receiver_thread.join()

        message = Message(MessageType.EVAL_MODEL.value, data={'payload': data})
        id_request = message.get_header()['id_request']

        try:
            self.send_message(message)

        except Exception as fl_ex:
            logger.exception(
                'Error occurred while sending EVAL request to parties'
                + str(fl_ex)
            )
            raise FLException(
                'Error occurred while sending EVAL request to parties'
            )

        return id_request

    def sync_model_parties(self, party_ids, data):
        """
        Send global model to a list of parties by constructinga message
        with MessageType as `SYNC` and packaging the model as payload

        :param party_ids: List of parties selected for an epoch
        :type party_ids: `lst`
        :param data: query information which is sent to each party
        :type data: `dict`
        :return: message number
        :rtype: `int`
        """
        self.connection.receiver.set_stopable()
        self.connection.receiver_thread.join()

        message = Message(MessageType.SYNC_MODEL.value, data={'payload': data})
        id_request = message.get_header()['id_request']

        try:
            self.send_message(message)

        except Exception as fl_ex:
            logger.exception(
                'Error occurred while sending SYNC request to parties'
                + str(fl_ex)
            )
            raise FLException(
                'Error occurred while sending SYNC request to parties'
            )

        return id_request

    def save_model_parties(self, party_ids, data):
        """
        Send save model request to parties by constructing a message with
        MessageType as `SAVE_MODEL` and packaging the data as payload

        :param party_ids: List of parties selected for an epoch
        :type party_ids: `lst`
        :param data: query information which is sent to each party
        :type data: `dict`
        :return: message number
        :rtype: `int`
        """
        self.connection.receiver.set_stopable()
        self.connection.receiver_thread.join()

        message = Message(MessageType.SAVE_MODEL.value, data={'payload': data})
        id_request = message.get_header()['id_request']

        try:
            self.send_message(message)

        except Exception as fl_ex:
            logger.exception(
                'Error occurred while sending SAVE request to parties'
                + str(fl_ex)
            )
            raise FLException(
                'Error occurred while sending SAVE request to parties'
            )

        return id_request

    def stop_parties(self):
        """
        STOP all available parties.

        :return: message number
        :rtype: `int`
        """
        self.connection.receiver.set_stopable()
        self.connection.receiver_thread.join()

        party_ids = self.get_available_parties()

        message = Message(MessageType.STOP.value, None)
        id_request = message.get_header()['id_request']

        try:
            messages = [message for _ in range(len(party_ids))]

            self.send_messages(party_ids, messages)
        except Exception as fl_ex:
            logger.exception(
                'Error occurred while sending STOP request to parties'
                + str(fl_ex)
            )

        return id_request
